import { Component, OnInit } from '@angular/core';
import { slideToTop } from '../../router-animation/router-animation.component';
import { MyserviceService } from 'src/app/myservice.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-territory-detail',
  templateUrl: './territory-detail.component.html',
  animations: [slideToTop()],
})
export class TerritoryDetailComponent implements OnInit {
  state:any=[];
  search:string;
  data:any={};
  form:any={};
  district:any=[];
  districts:any=[];
  districtnew:any=[];
  statecheck:boolean=false;
  
  checkbox:any=[];
  data_district=[];
  form_statelist:any=[];
  form_pincodelist:any=[];
  form_districtlist:any=[];
  pincode:any=[];
  territory_data:any=[];
  stateinput;
  update_data:any=[];
  id:any;
  terretoryList:any;
  statearrey:any=[];
  districtarrey:any=[];
  pinarrey:any=[];
  user_territory_data:any=[];
  territory_id:any='';
  allstatecheck:boolean=false;
  
  constructor(public route:ActivatedRoute,public router:Router,public service:MyserviceService,public browser:BrowserAnimationsModule) 
  { 
  
    this.route.params.subscribe(data=>
      {
        this.territory_id = data.id;
        console.log("territory id : "+this.territory_id);
        this.get_territory_data();
      });
      
    }
    ngOnInit() {
    }
    
    get_territory_data()
    {
      this.service.get_data(this.territory_id,'Territory_master/edit_territory_data').subscribe((resp)=>
      {
        console.log(resp);      
        this.user_territory_data=resp['data'];         
        this.split_data();
        this.get_state();
        this.dataupdatedistrict();      
      });
    }
    
    split_data()
    {
      if(this.user_territory_data)
      {
        this.form=this.user_territory_data;
        if(this.user_territory_data)
        {      
          this.statearrey = (this.user_territory_data['state_name']).split(",");
          console.log(this.statearrey);
          
          var len=this.statearrey.length;        
          for(var i=0;i<len-1;i++)
          {
            if(this.statearrey[i])
            {
              console.log(this.statearrey[i]);
              this.getDistrictList(this.statearrey[i],true);
              console.log(this.getDistrictList);
            }      
          }
          
          this.districtarrey = (this.user_territory_data['district_name']).split(",");   
          console.log(this.districtarrey);
          var len = this.districtarrey.length;
          for(var i=0; i<len-1; i++)
          {
            if(this.districtarrey[i])
            {
              this.getPincodeList(this.statearrey[i],this.districtarrey[i],true);
            }
          }
          
          this.pinarrey = (this.user_territory_data['pincode']).split(",");
          var len = this.pinarrey.length;
          for(var i=0; i<len; i++)
          {
            if(this.pinarrey[i])
            {
              console.log(this.pinarrey[i]);
              this.storepincode(this.pinarrey[i],true,i);
            }
          }
        }      
      }
    }
    
    
    
    finalData:any=[];
   
    searchfun(state_name)
    { 
      this.service.get_data({'state_name':state_name},'Territory_master/search_territory')
      .subscribe((result)=>{
        this.data=result['data'][0];
        
      });
    }
    
    active:any = {};
    toggleterritory(key,action)
    {
      if(action == 'open')
      { this.active[key] = true; }
      if(action == 'close')
      { this.active[key] = false;}
      
      console.log(this.active);
    }
    selectedAll:any;
    
    toogle_check(){
      this.statecheck = !this.statecheck;
    }
    districtCheckbox:boolean=false;
    district_toggle()
    {
      this.districtCheckbox =!this.districtCheckbox;
    }
    pincodecheckbox:boolean=false;
    pincode_toggle()
    {
      this.pincodecheckbox=!this.pincodecheckbox;
    }  
    territory:any=[];
    scope:any=[];
    onsubmit()
    {
      
      var st="";
      console.log(this.form_statelist);
      this.form_statelist.forEach(function(entry)
      {
        console.log(entry);
        console.log(entry.state_name);
        console.log(st);
        st=st+entry.state_name+",";
        console.log(st);
      });
      
      var dt="";
      this.form_districtlist.forEach(function(entry) {
        dt=dt+entry.district_name+",";
      });
      
      var pn="";
      this.form_pincodelist.forEach(function(entry) {
        pn=pn+entry.pin_code+",";
      });    
      this.form.state_name=st;
      this.form.district_name=dt;
      this.form.pincode=pn;   
      
      console.log(this.form);
      // this.service.get_data(this.form,'user/territory_update')
      // .subscribe((result)=>{
      //   this.territory_data= result;
      //   this.router.navigate(['/territory-list']);
      // });
      
    } 
    get_state()
    {
      this.service.get_data(0,'Territory_master/get_state').subscribe((result)=>
      {
        this.state=result['data'];
        console.log(this.state);    
        this.datastateupdate();  
      });
    }
    districtList(state_name)
    {
      console.log(state_name);   
      this.service.get_data({'state_name':state_name},'Territory_master/get_district')
      .subscribe((result)=>
      {
        this.data=result;
        this.districtnew=result; 
        this.districts.push({'state_name':state_name, 'district': this.districtnew } ); 
        console.log(this.districts);   
        this.dataupdatedistrict();  
      });
    }
    
    
    getDistrictListForAllState(state_name,e)
    { 
      // all state check button
      console.log("state");
      
      if(e.checked) 
      {
        console.log(e.checked);
        this.allstatecheck=true;
        this.statecheck=true;
        for(var i=0;i<state_name.length;i++)
        {
          this.districtList(state_name[i]['state_name']);
          this.storestate(state_name[i]['state_name']);
        }
        console.log("Out of for loop in if all checked");
        this.allstatecheck=false;
      }
      else
      {
        console.log(e.checked);
        this.allstatecheck=false;
        this.statecheck=false;
        for(var i=0;i<state_name.length;i++)
        {
          this.removeDist(state_name[i]['state_name']);
          this.removeStateListData(state_name[i]['state_name']);
          if(this.pincodes.length>0)
          {
            this.remove_pin_asper_state(state_name[i]['state_name']);
          }
        }
        console.log(this.allstatecheck);
        console.log("Out of for loop in else all checked");
        
      }
      if(this.allstatecheck==false)
      {
        
        this.removeDist(state_name);
        this.removeStateListData(state_name);
      }
    }
    
    
    state_name_new:any=[];
    filter_district:any=[];                                // for state change function
    getDistrictList(state_name,e) 
    { 
      console.log(e);
      if(e.checked || e == true){
        this.allstatecheck=false;
        this.districtList(state_name);  
        this.storestate(state_name);
      }
      
      else if(e.checked==false)
      {
        console.log('else if');
        this.removeDist(state_name);
        this.removeStateListData(state_name);
        if(this.pincodes.length>0){
          this.remove_pin_asper_state(state_name);
        }
      }
    }
    
    removeDist(state_name)
    {
      var a = this.districts.findIndex(items =>items.state_name === state_name)
      if(a !='-1')
      this.districts.splice(a,1);
      this.form_districtlist.splice(a, 1);
    }
    
    remove_pin_asper_state(state_name){
      console.log(state_name);
      for(var i=0;i<=this.pincodes.length;i++){
        var a = this.pincodes.findIndex(items =>items.state_name === state_name)
        if(a !='-1')
        {
          console.log(this.pincodes);
          this.pincodes.splice(a,1);
          console.log(this.pincodes);
          this.form_pincodelist.splice(a,1);
          console.log(this.form_pincodelist);
          
        }
        console.log(this.form_pincodelist);
        
      }
    }
    
    
    removeStateListData(state_name) {  
      console.log("remove");
      var x = this.form_statelist.findIndex(items => items.state_name === state_name);
      if(x  != '-1')
      this.form_statelist.splice(x, 1);
    } 
    
    stateList:any=[];
    storestate(state_name) {
      if(state_name) {
        console.log(state_name);
        this.form_statelist.push({state_name: state_name});  
        if(this.form_statelist.length=='36'){
          this.allstatecheck=true;
        }
      }  
    }
    
    
    state_name:any=[];
    getPincodeList(state_name,district_name,e)
    {    
      console.log(state_name);
      console.log(district_name);
      console.log(e);
      
      
      
      if(e.checked || e==true){
        this.pincodeList(state_name,district_name);
        this.storedistrict(state_name,district_name);
      }
      else if(e.checked==false)
      {
        this.removepincodeData(district_name);
        this.removeDistrictListData(district_name);
      }
    }
    storedistrict(stateinp,district_name) {
      if(district_name) {
        this.form_districtlist.push({'state_name':stateinp,'district_name':district_name});      
      }     
    }
    removeDistrictListData(district_name) {
      console.log(district_name);
      console.log(this.form_districtlist);
      console.log(this.districts);
      
      var x = this.form_districtlist.findIndex(items => items.district_name === district_name);
      
      if(x  != '-1')
      {
        
        this.form_districtlist.splice(x, 1);
        this.districts.splice(x, 1)
      }
      console.log(this.districts);
      console.log( this.form_districtlist);
      
    } 
    
    removepincode(district_name)
    {
      var len=this.pincode.length;
      console.log(this.pincode);
      for(var l1=0;l1<len;l1++)
      {
        var a = this.pincode.findIndex(items =>items.pincode === this.pincode)
        if(a !='-1')this.pincode.splice(a,1);
        console.log(this.pincode);
      }
      
    }
    
    pincodeListing:any=[];
    pincodeData:any=[];
    
    removepincodeData(d){
      console.log(d);
      
      for(var i=0;i<=this.form_pincodelist.length;i++  )
      {      
        var a = this.form_pincodelist.findIndex(items =>items.district_name === d )
        if(a !='-1')
        this.form_pincodelist.splice(a,1);
      }
      for(var i=0;i<=this.pincodes.length;i++)
      {      
        var a = this.pincodes.findIndex(items =>items.district_name === d)
        if(a !='-1')this.pincodes.splice(a,1);
      }
    }
    pincodes:any=[];
    pincodeList(state_name,district_name)
    {      
      this.service.get_data({'state_name':state_name,'district_name':district_name},'Territory_master/get_pincode')
      .subscribe((result)=>{
        console.log(result);
        this.pincode = result['data'];
        this.pincodes.push({'state_name':state_name,'district_name':district_name,'pincode':this.pincode});
        console.log(this.pincodes);
        this.dataupdatedpincode();      
      });
    } 
    
    storepincode(pincode,e,index) {
      console.log(pincode);
      console.log(e);
      
      if(pincode) {
        if(e)
        {
          this.form_pincodelist.push({pin_code: pincode});  
         
        }
        else 
        {
          console.log("splice-------------------");
        
          this.form_pincodelist.splice(index,1);
          console.log(this.form_pincodelist);
        }             
      }     
    }
    
    removePincode(pincode,e,index)
    {
      console.log(pincode);
      console.log(e);
      console.log(index);
      for(var i=0;i<=this.form_pincodelist.length;i++  )
      {      
        var a = this.form_pincodelist.findIndex(items =>items.pin_code === pincode )
        if(a !='-1')this.form_pincodelist.splice(a,1);
      }
      console.log(this.form_pincodelist);
      
      
    }
    // storepincode(pincode,e,index) {
    //   if(pincode) {
    //     if(e)
    //     {
    //       this.form_pincodelist.push({pin_code: pincode});  
    //       console.log('citylist');
    //       console.log(this.form_pincodelist);
    //     }
    //     else
    //     {
    //       console.log("splice-------------------");
    //         // for(var i=0; i<this.form_pincodelist.length; i++)
    //         // {
    //           // if(this.pincodes[index] = this.form_pincodelist[i])
    //           // {
    //             this.form_pincodelist.splice(index,1);
    //             console.log(this.form_pincodelist);
    
    
    //           // }
    //         // }
    
    
    //       // var x = this.form_pincodelist.findIndex(items => items.pin_code === pincode);
    //       // if(x  != '-1')this.form_pincodelist.splice(x, 1);
    //     }             
    //   }     
    // }
    
    // get_distict()
    // {
    //   this.service.get_data({},'Territory_master/get_distinct_district')
    //   .subscribe((result)=>{
    //     this.district=result['data'];  
    //     console.log(this.district);      
    //   });
    
    
    // }
    
    // get_distict_pncode()
    // {
    //   this.service.get_data({},'Territory_master/get_distinct_pincode')
    //   .subscribe((result)=>{
    //     this.pincode=result['data'];  
    //     console.log(this.pincode);
    //     // this.datapincodeupdate();
    
    //   });
    // }
    
    
    
    // getTerritoryDetail()
    // {   
    //   console.log(this.id);
    
    //   this.service.get_data(this.id,'Territory_master/edit_territory_data').subscribe((result:any)=>
    //   {
    //     console.log(result);
    
    //     this.terretoryList=result['data'];     
    //     console.log(this.terretoryList);
    //     this.form=this.user_territory_data;
    //     if(this.terretoryList)
    //     {      
    //       this.statearrey = (this.terretoryList['state_name']).split(",");
    //       // this.districtarrey = (this.terretoryList['district_name']).split(",");       
    //       this.datastateupdate();
    //       //  this.datadistrictupdate();
    
    //     }          
    //   });
    // }
    
    datastateupdate()
    {
      console.log(this.form_statelist);
      // console.log("=======state==========");
      
      console.log(this.state);
      
      for(var i=0;i<this.form_statelist.length;i++)
      {
        for(var j=0; j<this.state.length;j++)
        {
          if(this.form_statelist[i].state_name == this.state[j].state_name)
          {        
            this.state[j].state_value=true;
          }        
        }
      }
    }
    
    dataupdatedistrict()
    {
      // console.log('=====district=======');
      // console.log(this.form_districtlist);
      // console.log(this.districts.length);
      
      for(var i=0;i<this.form_districtlist.length;i++)
      {
        for(var j=0; j<this.districts.length;j++)
        {
          for(var k=0;k<this.districts[j].district.length;k++)
          {
            if(this.form_districtlist[i].district_name == this.districts[j].district[k].district_name)
            {
              this.districts[j].district[k].district_value=true;
            }        
          }
        }
        
      }
      // console.log(this.districts);
      
    }
    dataupdatedpincode()
    {
      console.log("======pincode======");
      console.log(this.form_districtlist);
      console.log(this.districts);
      console.log(this.pincodes);
      
      for(var i=0; i<this.form_districtlist.length; i++)
      {
        // console.log(this.form_districtlist[i].district_name);
        
        for(var j=0; j<this.pincodes.length; j++)
        {
          // console.log(this.pincodes[j].district_name);
          
          if(this.form_districtlist[i].district_name == this.pincodes[j].district_name)
          {
            this.pincodes[j].district_value = true;
          }
          
        }
        
        // console.log(this.pincodes);
        
        for(var i=0; i<this.form_pincodelist.length; i++)
        {
          for(var j=0; j<this.pincodes.length; j++)
          {
            for(var k=0; k<this.pincodes[j].pincode.length; k++)
            {
              if(this.form_pincodelist[i].pin_code == this.pincodes[j].pincode[k].pincode)
              {
                this.pincodes[j].pincode[k].pincode_value = true;
              }
            }
          }
        }
      }    
      console.log(this.pincodes);    
    }
    
    // dataupdatedpincode()
    // {
    //   console.log("======pincode======");
    //   console.log(this.form_districtlist);
    //   console.log(this.districts);
    //   console.log(this.pincodes);
    
    //   for(var i=0; i<this.form_districtlist.length; i++)
    //   {
    //     console.log(this.form_districtlist[i].district_name);
    
    //     for(var j=0; j<this.pincodes.length; j++)
    //     {
    //       console.log(this.pincodes[j].district_name);
    
    //       if(this.form_districtlist[i].district_name == this.pincodes[j].district_name)
    //       {
    //         this.pincodes[j].district_value = true;
    //       }
    
    //     }
    
    //     console.log(this.pincodes);
    
    //     for(var i=0; i<this.form_pincodelist.length; i++)
    //     {
    //       for(var j=0; j<this.pincodes.length; j++)
    //       {
    //         for(var k=0; k<this.pincodes[j].pincode.length; k++)
    //         {
    //           if(this.form_pincodelist[i].pin_code == this.pincodes[j].pincode[k].pincode)
    //           {
    //             this.pincodes[j].pincode[k].pincode_value = true;
    //           }
    //         }
    //       }
    //     }
    //   }    
    //   console.log(this.pincodes);    
    // }
  }
  