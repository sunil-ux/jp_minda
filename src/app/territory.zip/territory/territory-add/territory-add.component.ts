import { Component, OnInit } from '@angular/core';
import { slideToTop } from '../../router-animation/router-animation.component';
import { MyserviceService } from 'src/app/myservice.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { DialogBoxService } from 'src/app/dialog-box.service';

@Component({
  selector: 'app-territory-add',
  templateUrl: './territory-add.component.html',
  animations: [slideToTop()],
})
export class TerritoryAddComponent implements OnInit {
  state:any=[];
  search:string;
  data:any={};
  form:any={};
  district:any=[];
  districtnew:any=[];
  statecheck:boolean=false;
  allstatecheck:boolean=false;
  checkbox:any=[];
  data_district=[];
  form_statelist:any=[];
  form_pincodelist:any=[];
  form_districtlist:any=[];
  pincode:any=[];
  territory_data:any=[];
  stateinput;
  update_data:any=[];
  loader:any=1;
  valid: boolean=false;
  allpincodecheck:boolean=false;
  // selectedpincode: boolean=false;
  pincodecheckbox:boolean=false;
  currentpincode:boolean=false;
  onlycheckthispincode: boolean;
  constructor(public router:Router,public service:MyserviceService,public browser:BrowserAnimationsModule, public dialog:DialogBoxService) 
  {

    this.get_state();
  }
  
  finalData:any=[];
  showSaleUserList()
  {
    this.service.get_data({},'').subscribe((result)=>{   
    });
  }
  
  toggleCheckState()
  {
  }
  ngOnInit() {  }
  
  searchfun(state_name)
  { 
    this.service.get_data({'state_name':state_name},'Territory_master/search_territory').subscribe((result)=>{
      this.data=result['data'][0];
    });
  }
  
  active:any = {};
  toggleterritory(key,action)
  {
    if(action == 'open')
    { this.active[key] = true; }
    if(action == 'close')
    { this.active[key] = false;}
    console.log(this.active);
  }
  selectedAll:any;
  
  toogle_check(){
    this.statecheck = !this.statecheck;
  }
  districtCheckbox:boolean=false;
  district_toggle()
  {
    this.districtCheckbox =!this.districtCheckbox;
  }
  pincode_toggle()
  {
    this.pincodecheckbox=!this.pincodecheckbox;
  }  
  territory:any=[];
  scope:any=[];
  
  onsubmit()
  {
    var st="";
    this.form_statelist.forEach(function(entry) 
    {
      st=st+entry.state_name+",";
      // console.log(st);
    });
    
    var dt="";
    this.form_districtlist.forEach(function(entry) 
    {
      dt=dt+entry.district_name+",";
    });
    
    var pn="";
    this.form_pincodelist.forEach(function(entry) 
    {
      pn=pn+entry+",";
      console.log(pn);
      
    });    
    
    this.form.state_name=st;
    this.form.district_name=dt;
    this.form.pincode=pn;   
    console.log(this.form);
    if(this.form.district_name && this.form.pincode  &&  this.form.state_name && this.form.territory_name ){
      this.valid=true;
      this.service.get_data(this.form,'Territory_master/add_territory').subscribe((result)=>
      {
        this.territory_data= result;
        this.dialog.success("Success",'Inserted');
        this.router.navigate(['/territory-list']);
      },error =>{
        console.log(error);
        this.dialog.error('Something went wrong !!! Try Again...');
      });
      console.log(this.valid);
    }
    else 
    {
      this.valid=false;
      this.dialog.error("All the fields are required");
      
      console.log(this.valid);
    }
  } 
  get_state()
  {
    this.service.get_data(0,'Territory_master/get_state').subscribe((result)=>
    {
      console.log(result);
      this.loader='';
      this.state=result['data'];  
      console.log(this.state);
      
    });
  }
  
  state_name_new:any=[];
  getDistrictListForAllState(state_name,e)
  { 
    // all state check button
    if(e.checked) 
    {
      console.log(e.checked);
      this.allstatecheck=true;
      this.statecheck=true;
      for(var i=0;i<state_name.length;i++)
      {
        this.districtList(state_name[i]['state_name']);
        this.storestate(state_name[i]['state_name']);
      }
      console.log("Out of for loop in if all checked");
      // this.allstatecheck=false;
    }
    else
    {
      console.log(e.checked);
      this.allstatecheck=false;
      this.statecheck=false;
      for(var i=0;i<state_name.length;i++)
      {
        this.removeDist(state_name[i]['state_name']);
        this.removeStateListData(state_name[i]['state_name']);
        if(this.pincodes.length>0)
        {
          this.remove_pin_asper_state(state_name[i]['state_name']);
        }
      }
      console.log(this.allstatecheck);
      console.log("Out of for loop in else all checked");
      
    }
    if(this.allstatecheck==false)
    {
      this.removeDist(state_name);
      this.removeStateListData(state_name);
    }
  }
  count : any=0;
  getDistrictList(state_name,e)
  { 
    // single state check
    console.log(e.checked);
    if(e.checked==false)
    {
      console.log("i am in if checked false");
      console.log(e.checked);
      console.log(this.allstatecheck);
      this.allstatecheck=false;
    }
    
    if(e.checked) 
    {
      console.log(e.checked);
      this.allstatecheck=false;
      console.log(this.state.length);
      console.log(e.checked);
      
      this.districtList(state_name);
      this.storestate(state_name);
      
    }
    else
    {
      this.removeDist(state_name);
      this.removeStateListData(state_name);
      if(this.pincodes.length>0)
      {
        this.remove_pin_asper_state(state_name);
      }
    }
  }
  
  removeDist(state_name)
  {
    console.log("i am removdist function");
    
    var a = this.district.findIndex(items =>items.state_name === state_name)
    if(a !='-1')this.district.splice(a,1);
  }
  
  remove_pin_asper_state(state_name)
  {
    for(var i=0;i<=this.pincodes.length;i++)
    {
      var a = this.pincodes.findIndex(items =>items.state_name === state_name)
      if(a !='-1')this.pincodes.splice(a,1);
    }
  }
  districtList(state_name)
  {
    console.log("i am in district list function");
    this.loader="1";
    console.log(state_name);
    
    this.service.get_data({'state_name':state_name},'Territory_master/get_district').subscribe((result)=>
    {
      this.data=result;
      this.districtnew=result;  
      this.district.push({'state_name':state_name, 'district': this.districtnew } ); 
      this.loader='';
      
    });
  }
  
  
  removeStateListData(state_name) 
  {    
    console.log("i am removeStateListData function");
    
    var x = this.form_statelist.findIndex(items => items.state_name === state_name);
    if(x  != '-1')this.form_statelist.splice(x, 1);
    
  } 
  
  stateList:any=[];
  storestate(state_name) 
  {
    console.log("i am storestate function");
    
    console.log(state_name);
    if(state_name) 
    {
      this.form_statelist.push({state_name: state_name});  
      console.log(this.form_statelist);
      if(this.form_statelist.length=='36'){
        this.allstatecheck=true;
      }
    }  
  }
  
  
  state_name:any=[];
  getPincodeList(state_name,district_name,e)
  {    
    console.log(" i  am  in pincode list ");
    this.allpincodecheck=false;
    this.currentpincode=false;
    if(e.checked)
    {
      this.pincodeList(state_name,district_name);
      this.pincodestore(state_name);
      this.storedistrict(state_name,district_name);
    }
    else
    {
      this.removepincode(state_name);
      this.removepincodeData(district_name);
      this.removeDistrictListData(district_name);
    }
  }
  
  storedistrict(stateinp,district_name) 
  {
    console.log("i am store district function");
    console.log(stateinp);
    console.log(district_name);
    
    if(district_name) 
    {
      this.form_districtlist.push({'state_name':stateinp,'district_name':district_name});      
    }     
    console.log(this.form_districtlist);
  }
  
  removeDistrictListData(district_name) 
  {
    console.log("i am removeDistrictListData function");
    var x = this.form_districtlist.findIndex(items => items.district_name === district_name);
    if(x != '-1')this.form_districtlist.splice(x, 1);
  } 
  
  getAllPincodeOfParticulars(data,district,e)
  {
    console.log("current selected district : "+district);
    console.log(data);
    console.log(e.checked);
    console.log(this.allpincodecheck);
    if(e.checked)
    {
      this.allpincodecheck=true;
      let filterRow= data.filter(x => x.district_name == district)[0];
      console.log(filterRow);
      console.log(filterRow.pincode);
      // console.log(this.form_districtlist);
      // console.log(filterRow.pincode.length);


      // for(var j=0;j<filterRow.length;j++)
      // {
        
      // }





      for(var i=0;i<filterRow.pincode.length;i++)
      {
        // this.onlycheckthispincode=true;
        this.currentpincode=true;
        this.pincodecheckbox=true;
        this.form_pincodelist.push(filterRow.pincode[i]['pincode']);  
      }
      console.log(this.form_pincodelist);
    }
    else
    {
      this.currentpincode=false;
      this.pincodecheckbox=false;
      this.allpincodecheck=false;
      this.form_pincodelist=[];
      console.log(this.form_pincodelist);
    }
  }
  
  removepincode(district_name)
  {
    var len=this.pincode.length;
    for(var l1=0;l1<len;l1++)
    {
      var a = this.pincode.findIndex(items =>items.pincode === this.pincode)
      if(a !='-1')this.pincode.splice(a,1);
    }
  }
  
  pincodeListing:any=[];
  pincodeData:any=[];
  
  pincodestore(st)
  {
  }
  
  removepincodeData(d)
  {
    for(var i=0;i<=this.pincodes.length;i++)
    {      
      var a = this.pincodes.findIndex(items =>items.district_name === d)
      if(a !='-1')this.pincodes.splice(a,1);
    }
  }
  pincodes:any=[];
  pincodeList(state_name,district_name)
  {      
    this.loader="1";
    this.service.get_data({'state_name':state_name,'district_name':district_name},'Territory_master/get_pincode').subscribe((result)=>
    {
      console.log("testing1");
      console.log(result);
      this.pincode = result['data'];
      this.pincodes.push({'state_name':state_name,'district_name':district_name,'pincode':this.pincode});
      this.loader='';
    });
  } 
  
  storepincode(pincode,e,index) 
  {
    if(pincode) 
    {
      //single pincode check
      console.log(e.checked);
      if(e.checked==false)
      {
        console.log("i am in if checked false");
        console.log(e.checked);
        console.log(this.allpincodecheck);
        this.allpincodecheck=false;
      } 
      
      if(e.checked)
      {
        console.log(pincode);
        this.form_pincodelist.push(pincode);  
        console.log('citylist');
        console.log(this.form_pincodelist);
       console.log(this.form_pincodelist.length);
       console.log(this.pincode.length);
       
      //  current selected district pincode length
       
        if(this.form_pincodelist.length==this.pincode.length){
          this.allpincodecheck=true;
        }


      }
      else
      {
        console.log(this.form_pincodelist[0]);
        console.log(this.pincode[index]);
        
        for(var i=0; i<this.form_pincodelist.length; i++)
        {
          if(this.pincode[index]['pincode']==this.form_pincodelist[i])
          {
            this.form_pincodelist.splice(i,1);
          }
        }
        console.log(this.form_pincodelist);
        
        
        // var x = this.form_pincodelist.findIndex(items => items.pin_code === pincode);
        // if(x  != '-1')this.form_pincodelist.splice(x, 1);
      }             
    }     
  }
  
}
